# Liquid-API

Liquid API is a custom api make by Rocko. Supports most functions and has powerful execution.

# How To Use

Download Liquid API from the realeses and add it to your refrences

![image](https://github.com/RockoOffical/Liquid-API/assets/142240613/0e7b89fa-191e-41c5-98b9-739bdd5c18d7)
![image](https://github.com/RockoOffical/Liquid-API/assets/142240613/9440009e-1b7a-4f4a-b943-e95a934de995)

After adding the refrence go to your main C# code and add the follow

![image](https://github.com/RockoOffical/Liquid-API/assets/142240613/8329cf15-f06e-43ea-a9d2-181d28905212)

And the under "public partial class YourFormName : Form" add the following

![image](https://github.com/RockoOffical/Liquid-API/assets/142240613/265b2af5-ac81-4099-896e-79cebf2fcfda)

# Execution And Injection/Attaching

Make a script box or rich text box and then add a button and label it execute. After double click the execute button and add this code

![image](https://github.com/RockoOffical/Liquid-API/assets/142240613/9ef887e0-6942-4497-985f-39917ec10633)

Now make another button and label it inject. Then double click it and add this code

![image](https://github.com/RockoOffical/Liquid-API/assets/142240613/2b5df78d-7ef6-4584-a101-4bd5ee809f8c)

Now start the project and your good to go!




